import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './userlist.css';

const UserProfileList = (props) => {
  const [userProfiles, setUserProfiles] = useState([]);
  const {setOption, setProfile}=props

  useEffect(() => {
    axios
      .get('http://localhost:4000/api/api/user-profiles')
      .then((res) => {
        const userProfiles = res.data;
        setUserProfiles(userProfiles);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleDelete = (userId) => {
    const updatedProfiles = userProfiles.filter(
      (profile) => profile._id !== userId
    );
    setUserProfiles(updatedProfiles);
    axios
      .delete(`http://localhost:4000/api/${userId}`)
      .then((response) => {
        console.log(response.data.message);
      })
      .catch((error) => {
        console.log(error.response.data.error);
      });
  };

  const handleUpdate = (userProfile) => {

    // axios
    //   .put(`http://localhost:4000/api/${userId}`, {
    //     profileImg: "new-profile-img",
    //     title: "new-title",
    //     desc: "new-desc",
    //     githublink: "new-github-link"
    //   }) 
    //   .then((response) => {
    //     console.log(response.data.message);
    //     const updatedProfiles = userProfiles.map((profile) => {
    //       if (profile._id === userId) {
    //         return {
    //           ...profile,
    //           profileImg: "new-profile-img",
    //           title: "new-title",
    //           desc: "new-desc",
    //           githublink: "new-github-link"
    //         };
    //       }
    //       return profile;
    //     });
        // setUserProfiles(updatedProfiles);
        setOption(1);
        setProfile(userProfile);
      // })
      // .catch((error) => {
      //   console.log(error.response.data.error);
      // });
  }; 
    

  return (
    <div>
      <h2>Projects</h2>
      <ul>
        {userProfiles.map((userProfile) => (
          <li key={userProfile._id}>
            {console.log(userProfile.profileImg)}
            <img src={userProfile.profileImg} alt={userProfile.title} />
            <h3>{userProfile.title}</h3>
            <p>{userProfile.desc}</p>
            <a href={userProfile.githublink}>Github Link</a>
            <button onClick={() => handleUpdate(userProfile)}>
              Update
            </button>
            <button onClick={() => handleDelete(userProfile._id)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserProfileList;

// import React, { Component } from 'react';
// import axios from 'axios';
// import { Link } from 'react-router-dom';
// import './userlist.css';

// export default class UserProfileList extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       userProfiles: []
//     };
//   }

//   componentDidMount() {
//     axios
//       .get('http://localhost:4000/api/api/user-profiles')
//       .then((res) => {
//         const userProfiles = res.data;
//         this.setState({ userProfiles });
//       })
//       .catch((err) => {
//         console.log(err);
//       });
//   }

//   handleDelete = (userId) => {
//     const updatedProfiles = this.state.userProfiles.filter(
//       (profile) => profile._id !== userId
//     );
//     this.setState({ userProfiles: updatedProfiles });
//     axios
//       .delete("http://localhost:4000/api/"+userId)
//       .then((response) => {
//         console.log(response.data.message);
//       })
//       .catch((error) => {
//         console.log(error.response.data.error);
//       });
//   };

//   handleUpdate = (userId) => {
//     axios
//       .put("http://localhost:4000/api/" + userId, {
//         profileImg: "new-profile-img",
//         title: "new-title",
//         desc: "new-desc",
//         githublink: "new-github-link"
//       }) 
//       .then((response) => {
//         console.log(response.data.message);
//       })
//       .catch((error) => {
//         console.log(error.response.data.error);
//       });
//   }; 

//   render() { 
//     return (
//       <div>
//         <h2>Projects</h2>
//         <ul>
//           {this.state.userProfiles.map((userProfile) => (
//             <li key={userProfile._id}>
//               <img src={userProfile.profileImg} alt={userProfile.title} />
//               <h3>{userProfile.title}</h3>
//               <p>{userProfile.desc}</p>
//               <a href={userProfile.githublink}>Github Link</a>
//               <button onClick={() => this.handleUpdate(userProfile._id)}>
//                 Update
//               </button>
//               <button onClick={() => this.handleDelete(userProfile._id)}>
//                 Delete
//               </button>
//             </li>
//           ))}
//         </ul>
//       </div>
//     );
//   }
// }
// import React, { Component } from 'react';
// import axios from 'axios';
// import { Link } from 'react-router-dom';
// import './userlist.css';

// export default class UserProfileList extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       userProfiles: [],
//       profileImg: '',
//       title: '',
//       desc: '',
//       githublink: ''
//     };
//   }

//   componentDidMount() {
//     axios
//       .get('http://localhost:4000/api/api/user-profiles')
//       .then((res) => {
//         const userProfiles = res.data;
//         this.setState({ userProfiles });
//       })
//       .catch((err) => {
//         console.log(err);
//       });
//   }

//   handleDelete = (userId) => {
//     const updatedProfiles = this.state.userProfiles.filter(
//       (profile) => profile._id !== userId
//     );
//     this.setState({ userProfiles: updatedProfiles });
//     axios
//       .delete("http://localhost:4000/api/"+userId)
//       .then((response) => {
//         console.log(response.data.message);
//       })
//       .catch((error) => {
//         console.log(error.response.data.error);
//       });
//   };

//   handleInputChange = (event) => {
//     const { name, value } = event.target;
//     this.setState({ [name]: value });
//   };

//   handleUpdate = (userId) => {
//     axios
//       .put("http://localhost:4000/api/" + userId, {
//         profileImg: this.state.profileImg,
//         title: this.state.title,
//         desc: this.state.desc,
//         githublink: this.state.githublink
//       })
//       .then((response) => {
//         console.log(response.data.message);
//       })
//       .catch((error) => {
//         console.log(error.response.data.error);
//       });
//   };

//   render() {
//     return (
//       <div>
//         <h2>User Profiles</h2>
//         <ul>
//           {this.state.userProfiles.map((userProfile) => (
//             <li key={userProfile._id}>
//               <img src={userProfile.profileImg} alt={userProfile.title} />
//               <h3>{userProfile.title}</h3>
//               <p>{userProfile.desc}</p>
//               <a href={userProfile.githublink}>Github Link</a>
//               <form>
//                 <label>
//                   Profile Image:
//                   <input
//                     type="text"
//                     name="profileImg"
//                     value={this.state.profileImg}
//                     onChange={this.handleInputChange}
//                   />
//                 </label>
//                 <label>
//                   Title:
//                   <input
//                     type="text"
//                     name="title"
//                     value={this.state.title}
//                     onChange={this.handleInputChange}
//                   />
//                 </label>
//                 <label>
//                   Description:
//                   <input
//                     type="text"
//                     name="desc"
//                     value={this.state.desc}
//                     onChange={this.handleInputChange}
//                   />
//                 </label>
//                 <label>
//                   Github Link:
//                   <input
//                     type="text"
//                     name="githublink"
//                     value={this.state.githublink}
//                     onChange={this.handleInputChange}
//                   />
//                 </label>
//                 <button onClick={() => this.handleUpdate(userProfile._id)}>
//                   Update
//                 </button>
//               </form>
//               <button onClick={() => this.handleDelete(userProfile._id)}>
//                 Delete
//               </button>
//             </li>
//           ))}
//         </ul>
//       </div>
//     );
//   }
// }
