import React from "react"
import EmailSender from "./Contact/EmailSender"
import EmailList from "./Contact/EmailList"
export default function Mail()
{
    return(
        <>
        <EmailSender/>
      <EmailList/>
        </>
    )
}