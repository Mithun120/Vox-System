import { Col } from "react-bootstrap";

export const ProjectCard = ({ _id,profileImg,title,desc,githublink }) => {
  return (
    <Col size={12} sm={6} md={4}>
      <li key={_id}>
            {console.log(profileImg)}
            <div className="proj-imgbx">
            <img src={profileImg} alt={title} />
            <div className="proj-txtx">
            <h3>{title}</h3>
            <p>{desc}</p>
            <a href={githublink}>Github Link</a>
            </div>
            </div>
          </li>
      {/* <div className="proj-imgbx">
        <img src={imgUrl} />
        
          <h4>{title}</h4>
          <span>{description}</span>
        </div>
      </div> */}
    </Col>
  )
}
